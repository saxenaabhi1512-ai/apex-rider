# Apex Rider – Android (Play Store) project

Needs: Node.js 20+, Android Studio.

1. `npm install @capacitor/core @capacitor/cli @capacitor/android three@0.128.0`
2. `npx cap add android`
3. `npm run sync`        (makes the game offline and copies it into the Android project)
4. In `android/app/src/main/AndroidManifest.xml` add to the <activity> tag: `android:screenOrientation="sensorLandscape"`
5. Edit `capacitor.config.json` -> set your own `appId` (e.g. com.yourname.apexrider).
6. `npm run open`, then in Android Studio: set app icon, targetSdk = the level Play currently requires (API 36 for new apps), then Build > Generate Signed Bundle (AAB).
7. Play Console: upload the AAB, add icon 512x512, feature graphic 1024x500, screenshots, privacy policy URL (host privacy-policy.md as a web page), content rating and data safety (no data collected).
8. New personal developer accounts must run closed testing (12 testers, 14 days) before production - check Play Console for the current rule.

## Quickest way to get an APK (no Android Studio)
1. Create a free GitHub account and a new repository, upload everything in this folder (including the hidden `.github` folder).
2. Repository > Actions > "Build APK" > Run workflow.
3. When it finishes (a few minutes), open the run and download the `apex-rider-apk` artifact. Unzip it to get `app-debug.apk`.
4. Copy the APK to your phone and install it (allow "Install unknown apps" when asked).
The debug APK is for testing/sharing. The Play Store needs a signed AAB (see the steps above).
