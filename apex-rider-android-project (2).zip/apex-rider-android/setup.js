// Makes the game fully offline: copies three.js locally and removes the Google Fonts link (system fonts are used instead).
const fs = require('fs');
fs.copyFileSync('node_modules/three/build/three.min.js', 'www/three.min.js');
let h = fs.readFileSync('www/index.html', 'utf8');
h = h.replace('https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js', 'three.min.js')
     .replace(/<link rel="stylesheet" href="https:\/\/fonts[^>]*>/, '');
fs.writeFileSync('www/index.html', h);
console.log('Offline build ready in www/');
