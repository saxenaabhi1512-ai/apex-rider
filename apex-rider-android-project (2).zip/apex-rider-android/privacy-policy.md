# Privacy Policy – Apex Rider
Last updated: <DATE>

Apex Rider does not collect, send or share any personal data. The username, selected bike/rider, best times and the in-game prize wallet are stored only on your own device (local storage) and never leave it. The game has no ads, no analytics and no third-party SDKs. It does not ask for any device permissions.

Contact: <YOUR EMAIL>
